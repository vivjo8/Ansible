nodejs
======

This Ansible role installs Node.JS.
