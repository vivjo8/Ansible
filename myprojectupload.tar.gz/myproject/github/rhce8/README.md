This Git repository contains supporting files for my "Red Hat Certified Engineer (RHCE) EX294: Ansible Automation" video course. See https://sandervanvugt.com for more details. 
